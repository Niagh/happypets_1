-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 16 mai 2024 à 21:31
-- Version du serveur : 8.2.0
-- Version de PHP : 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `shop_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `profile`) VALUES
(1, 'rania', 'abidrania2@gmail.com', '123', 'glitch.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `price` varchar(10) NOT NULL,
  `qty` varchar(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `price`, `qty`) VALUES
('UzH7ynJfxmARltq6q5Sx', 'UAVjN46f0bvXSKquej8S', 'aSBHDzG26iXurm6cfoNv', '50', '1'),
('1guAonWHKia0jXM1gPEQ', 'Fkn1ZyULUPVQ2ipaePUR', '5', '19.99', '4');

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `message`
--

INSERT INTO `message` (`id`, `user_id`, `name`, `email`, `subject`, `message`) VALUES
('0', '0', 'ryan', 'ryan@gmail.com', 'shop', 'good'),
('Lm7uFQVcX3czwG0yX5p0', 'UAVjN46f0bvXSKquej8S', 'ryan', 'ryan@gmail.com', 'maths,science', 'kk');

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `address_type` varchar(10) NOT NULL,
  `method` varchar(50) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `price` varchar(10) NOT NULL,
  `qty` varchar(2) NOT NULL,
  `date` date NOT NULL DEFAULT (curdate()),
  `status` varchar(50) NOT NULL DEFAULT 'in progress',
  `payment_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `address`, `address_type`, `method`, `product_id`, `price`, `qty`, `date`, `status`, `payment_status`) VALUES
('EYZ94PhWrzea0s9Tdd2J', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '507A, 24 back side, Delhi, India, 110019', 'home', 'cash on delivery', 'BLTtlhOgq1cuz7plh4Ia', '123', '1', '2023-02-28', 'canceled', 'pending'),
('DStPLCBmD0m0OjAFYlhg', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '507A, 24 back side, Delhi, India, 110019', 'home', 'cash on delivery', 'jo35YMmBWpvbCMB65UdA', '160', '1', '2023-02-28', 'canceled', 'pending'),
('XyoWmad14f2YOWbi11XF', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '507A, 24 back side, Delhi, India, 110019', 'home', 'cash on delivery', 'aSBHDzG26iXurm6cfoNv', '50', '1', '2023-02-28', 'canceled', 'pending'),
('OGTzld6EmHmNHeXZQkB6', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '507A, 24 back side, Delhi, India, 110019', 'home', 'cash on delivery', 'uOarNNg0n3KD9OvPtItP', '80', '1', '2023-02-28', 'canceled', 'pending'),
('UUFMa328sIAdb3znDXce', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '567G, 24 back side, Delhi, India, 110080', 'home', 'credit or debit card', 'kun96OpQed6Eww6M1URo', '120', '1', '2023-02-28', 'canceled', 'complete'),
('Bsatz7miuWWgXMEx5qzW', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '507A, 24 back side, Delhi, India, 110019', 'home', 'cash on delivery', 'kun96OpQed6Eww6M1URo', '120', '1', '2023-02-28', 'in progress', 'complete'),
('4SJfc2GJY4ekJN45CKbP', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '507A, 24 back side, Delhi, India, 110019', 'home', 'cash on delivery', 'BLTtlhOgq1cuz7plh4Ia', '123', '1', '2023-02-28', 'in progress', 'pending'),
('Jd0yGYljvlchrTLd5KGQ', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '456A, 24 back side, Delhi, India, 110019', 'office', 'credit or debit card', 'BLTtlhOgq1cuz7plh4Ia', '123', '1', '2023-02-28', 'in progress', 'complete'),
('wtyNDfBfSwShC9FXFnbC', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '456A, 24 back side, Delhi, India, 110019', 'office', 'credit or debit card', 'aSBHDzG26iXurm6cfoNv', '50', '1', '2023-02-28', 'in progress', 'pending'),
('KRbSyH7ZgbVzWyyZQoiv', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '456A, 24 back side, Delhi, India, 110019', 'office', 'credit or debit card', 'uOarNNg0n3KD9OvPtItP', '80', '1', '2023-02-28', 'in progress', 'pending'),
('9vucKr2sSPqcIUidPedP', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '507A, 24 back side, Delhi, India, 110019', 'office', 'cash on delivery', 'kun96OpQed6Eww6M1URo', '120', '1', '2023-02-28', 'in progress', 'pending'),
('gq2RDUuhaPe7TDcxiGCy', 'UAVjN46f0bvXSKquej8S', 'mahi', '7788669955', 'mahinazir@gmail.com', '507A, 24 back side, Delhi, India, 110019', 'home', 'cash on delivery', 'g5DLcNHmtHvq3DtJYsCb', '80', '1', '2023-02-28', 'in progress', 'pending'),
('JqyfHoT9UzR4qcvp3LNJ', 'd5URvsP8VusCXQoCdMBG', 'shalu', '7788669955', 'shaluAnsari@gmail.com', '507A, 24 back side, mumbai, India, 110019', 'home', 'credit or debit card', 'BLTtlhOgq1cuz7plh4Ia', '123', '1', '2023-02-28', 'in progress', 'complete'),
('yyD4B276Pg9lfGpRjcr9', 'd5URvsP8VusCXQoCdMBG', 'shalu', '7788669944', 'shaluAnsari@gmail.com', '507A, 24 back side, mumbai, india, 112233', 'office', 'credit or debit card', 'jo35YMmBWpvbCMB65UdA', '160', '2', '2023-02-28', 'canceled', 'pending'),
('qV5WaHO0bjyaL2Vm0UVK', '', 'rania', '08980997', 'abidrania2@gmail.com', '30 boulevard de la federation, HELIOTROPE 2, H2, LDKLJDLSJ, Marseille--4e--Arrondissement - (13004), France, 13004', 'office', 'cash on delivery', 'BLTtlhOgq1cuz7plh4Ia', '123', '1', '2024-05-15', 'in progress', ''),
('S5cXofCBAuR6QhYsGjS5', '', 'ABID RANIA', '098987987', 'abidrania2@gmail.com', '30 boulevard de la federation, , Marseille 04, France, 13004', 'home', 'cash on delivery', 'BLTtlhOgq1cuz7plh4Ia', '123', '1', '2024-05-16', 'in progress', ''),
('RneBkqfTCKZGWrVA1ACh', '', 'ABID RANIA', '098087987', 'abidrania2@gmail.com', '30 boulevard de la federation, , Marseille 04, France, 13004', 'home', 'cash on delivery', 'BLTtlhOgq1cuz7plh4Ia', '123', '1', '2024-05-16', 'in progress', ''),
('ZOoGi0UJCOuEwqRY3e6Q', '', 'ABID RANIA', '098087987', 'abidrania2@gmail.com', '30 boulevard de la federation, , Marseille 04, France, 13004', 'home', 'cash on delivery', 'BLTtlhOgq1cuz7plh4Ia', '123', '1', '2024-05-16', 'in progress', ''),
('gADIR81ADHJF7bTYAY2H', '', 'ryan', '246736736', 'am@ksdhkhf.fr', 'KHK JSHDJDSHJSDH JSH, , MARSEILLE , FRANCE, 143343', 'home', 'cash on delivery', 'jo35YMmBWpvbCMB65UdA', '160', '1', '2024-05-16', 'in progress', ''),
('ksWmQ1SMSv9qOjeQNugF', '', 'ryan', '246736736', 'am@ksdhkhf.fr', 'KHK JSHDJDSHJSDH JSH, , MARSEILLE , FRANCE, 143343', 'home', 'cash on delivery', 'jo35YMmBWpvbCMB65UdA', '160', '1', '2024-05-16', 'in progress', ''),
('BHj1EXUp1FMw2IVMi7iO', '', 'ryan', '246736736', 'am@ksdhkhf.fr', 'KHK JSHDJDSHJSDH JSH, , MARSEILLE , FRANCE, 143343', 'home', 'cash on delivery', 'jo35YMmBWpvbCMB65UdA', '160', '1', '2024-05-16', 'in progress', ''),
('iy99z5pTsKe0Udvvgmgy', '', 'ryan', '246736736', 'am@ksdhkhf.fr', 'KHK JSHDJDSHJSDH JSH, , MARSEILLE , FRANCE, 143343', 'home', 'cash on delivery', 'jo35YMmBWpvbCMB65UdA', '160', '1', '2024-05-16', 'in progress', ''),
('avSFh8Vym0Am8d2HE2FP', '', 'RANIA', '4546546456', 'abidrania2@gmail.com', '30 boulevard de la federation, , Marseille 04, France, 13004', 'home', 'cash on delivery', '26lPPTjXh9EkNc7WocS5', '70', '1', '2024-05-16', 'in progress', ''),
('SSCpPG8FKwrzMuOMo5oA', 'J2ZseE8DTSrE9VJaZPqq', 'ryan', '9829496874', 'abidrania2@gmail.com', 'klsdjksk ksjdkdjsksjddskjdk , , marseillle, france, 13004', 'home', 'cash on delivery', '2', '450', '1', '2024-05-16', 'in progress', ''),
('0K0oT7YTBhFVmH7ZdQMH', 'J2ZseE8DTSrE9VJaZPqq', 'ryan', '9829496874', 'abidrania2@gmail.com', 'klsdjksk ksjdkdjsksjddskjdk , , marseillle, france, 13004', 'home', 'cash on delivery', '3', '50', '1', '2024-05-16', 'in progress', '');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `product_detail` varchar(500) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`, `product_detail`, `status`) VALUES
('1', 'Hamac Douillet En Coton\r\n', '100', '1.jpg', 'Description : Offrez à votre chat un endroit confortable pour se reposer avec ce hamac en coton doux. Facile à installer, il se fixe fermement sous les chaises ou tables pour un espace de détente suspendu.\r\nCaractéristiques :\r\nMatériau : 100% coton\r\nDimensions : 50 x 50 cm\r\nLavable en machine\r\nDisponible en plusieurs couleurs', 'active'),
('2', 'Arbre à Chat Multi-Niveaux avec Griffoir Intégré', '450', '2.jpg', 'Description : Cet arbre à chat multi-niveaux offre à votre félin de nombreuses possibilités de jeu et de repos. Équipé de griffoirs en sisal, de plateformes et de cachettes, il est parfait pour satisfaire ses instincts naturels.\r\nCaractéristiques :\r\nMatériau : Bois et sisal\r\nHauteur : 150 cm\r\nCouleurs : Gris, beige\r\nFacile à assembler', 'active'),
('3', 'Litière Naturelle Absorbante pour Hamster', '50', '3.jpg', 'Description : Gardez la cage de votre hamster propre et sans odeurs avec cette litière naturelle et absorbante. Elle est composée de matériaux biodégradables et sans danger pour les petits animaux.\r\nCaractéristiques :\r\nMatériau : Fibres végétales\r\nPoids : 2 kg\r\nHypoallergénique\r\nCompostable', 'active'),
('4', 'Jouet Interactif en Peluche pour Chien avec Son', '15', '4.jpg', 'Description : Ce jouet en peluche émet des sons amusants lorsque votre chien le mordille, stimulant ainsi ses instincts de jeu. Conçu pour être durable et résistant aux morsures.\r\nCaractéristiques :\r\nMatériau : Peluche et plastique\r\nTaille : 20 cm\r\nLavable à la main\r\nDisponible en plusieurs formes', 'active'),
('5', 'Balle à Friandises pour Hamster ', '19.99', '5.jpg', 'Description : Cette balle à friandises est parfaite pour garder votre hamster mentalement stimulé. Remplissez-la de ses friandises préférées et regardez-le résoudre le puzzle pour les obtenir.\r\nCaractéristiques :\r\nMatériau : Plastique', 'active'),
('6', 'Plaid pour Chien Malade – Confort et Chaleur', '9.99', '6.jpg', 'Description : Ce plaid doux et chaud est spécialement conçu pour les chiens malades ou en convalescence. Il procure un confort supplémentaire et aide à maintenir une température corporelle optimale.\r\nCaractéristiques :\r\nMatériau : Polaire douce\r\nDimensions : 100 x 70 cm\r\nLavable en machine\r\nAntistatique et hypoallergénique', 'active');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`) VALUES
('UAVjN46f0bvXSKquej8S', 'ryan', 'ryan@gmail.com', 'ryan786', 'user'),
('ir7qjxTxaQm9PM5drpEn', 'elisabeth2', 'elisabeth2@gmail.com', 'elisabeth2786', 'user'),
('GE2LLAWjKATiQRLHaa6O', 'Aiyman', 'aiyman@gmail.com', '12345', 'user'),
('d5URvsP8VusCXQoCdMBG', 'erika', 'delobelle@gmail.com', '12345', 'user'),
('J2ZseE8DTSrE9VJaZPqq', 'rania', 'rania@gmail.com', '123', 'user'),
('Fkn1ZyULUPVQ2ipaePUR', 'rania', 'abidrania2@gmail.com', '123', 'user'),
('j0ktkwbXB0xH3DFsLNSs', 'erika', 'root@gmail.com', '123', 'user');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
