<div class="top-footer">
	<h2><i class="bx bx-envelope"></i>Inscrivez-vous à la newsletter</h2>
	<div class="input-field">
		<input type="text" name="" placeholder="adresse email...">
		<button class="btn">s'abonner</button>
	</div>
</div>
<footer>
	<div class="overlay"></div>
	<div class="footer-content">
		<div class="img-box">
			<img src="img/notrelogo2.png">
		</div>
		<div class="inner-footer">
			<div class="card">
				<h3>à propos de nous</h3>
				<ul>
					<li>à propos de nous</li>
					<li>Vive les animaux</li>
					<li>blog</li>
				</ul>
			</div>
			<div class="card">
				<h3>services</h3>
				<ul>
					<li>commander</li>
					<li>Assistance</li>
					<li>expédition</li>
					<li>conditions d'utilisation</li>
					<li>détails du compte</li>
					<li>mon compte</li>
				</ul>
			</div>
			<div class="card">
				<h3>Livraison</h3>
				<ul>
					<li>Marseille</li>
					<li>Aix</li>
					<li>Cavaillon</li>
				</ul>
			</div>
			<div class="card">
				<h3>newsletter</h3>
				<p>Inscrivez-vous à la newsletter</p>
				<div class="social-links">
					<i class="bx bxl-instagram"></i>
					<i class="bx bxl-twitter"></i>
					<i class="bx bxl-youtube"></i>
					<i class="bx bxl-whatsapp"></i>
				</div>
			</div>
		</div>
		<div class="bottom-footer">
			<p>Bienvenue - Arnaud & Rania</p>
		</div>
	</div>
</footer>
