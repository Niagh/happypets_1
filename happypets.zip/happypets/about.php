<?php 
 include 'components/connection.php';
 session_start();
 if (isset($_SESSION['user_id'])) {
		$user_id = $_SESSION['user_id'];
	}else{
		$user_id = '';
	}

	if (isset($_POST['logout'])) {
		session_destroy();
		header("location: login.php");
	}
?>
<style type="text/css">
	<?php include 'style.css'; ?>
</style>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<title>Green Coffee - page à propos de nous</title>
</head>
<body>
	<?php include 'components/header.php'; ?>
	<div class="main">
		<div class="banner">
			<h1>à propos de nous</h1>
		</div>
		<div class="title2">
			<a href="home.php">accueil </a><span>/ à propos</span>
		</div>
		<!--<div class="about-category">
			<div class="box">
				<img src="img/3.webp">
				<div class="detail">
					<span>café</span>
					<h1>lemon green</h1>
					<a href="view_products.php" class="btn">acheter maintenant</a>
				</div>
			</div>
			<div class="box">
				<img src="img/2.webp">
				<div class="detail">
					<span>café</span>
					<h1>lemon Teaname</h1>
					<a href="view_products.php" class="btn">acheter maintenant</a>
				</div>
			</div>
			<div class="box">
				<img src="img/about.png">
				<div class="detail">
					<span>café</span>
					<h1>lemon Teaname</h1>
					<a href="view_products.php" class="btn">acheter maintenant</a>
				</div>
			</div>
			<div class="box">
				<img src="img/1.webp">
				<div class="detail">
					<span>café</span>
					<h1>lemon green</h1>
					<a href="view_products.php" class="btn">acheter maintenant</a>
				</div>
			</div>
		</div>
		
		<div class="about">
			<div class="row">
				<div class="img-box">
					<img src="img/3.png">
				</div>-->
				<div class="detail">
					<h1>visitez notre magnifique catalogue !</h1>
					<p></p>
                    <a href="view_products.php" class="btn">acheter maintenant</a>
				</div>
			</div>
		</div>
		<div class="testimonial-container">
			<div class="title">
				<img src="img/download.png" class="logo">
				<h1>ce que les gens disent de nous</h1>
            </div>
                <div class="container">
                	<div class="testimonial-item active">
                		<h1> Beyonce </h1>
                		<p>got me looking so crazy in love</p>
                	</div>
                	<div class="testimonial-item">
                		<h1>Celine Dion</h1>
                		<p>Everyyyy night in my dreams, i see your web siiiiite....</p>
                	</div>
                	<div class="testimonial-item">
                		<h1>Jul</h1>
                		<p>Wesh c'est beau!</p>
                	</div>
                	<div class="testimonial-item">
                		<h1>Francis cabrel</h1>
                		<p>Je l'aime à mourir le site</p>
                	</div>
                	<div class="left-arrow" onclick="nextSlide()"><i class="bx bxs-left-arrow-alt"></i></div>
                	<div class="right-arrow" onclick="prevSlide()"><i class="bx bxs-right-arrow-alt"></i></div>
                </div>
		</div>
		<?php include 'components/footer.php'; ?>
	</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
	<script src="script.js"></script>
	<script type="text/javascript">
		let slides = document.querySelectorAll('.testimonial-item');
		let index = 0;

		function nextSlide(){
		    slides[index].classList.remove('active');
		    index = (index + 1) % slides.length;
		    slides[index].classList.add('active');
		}
		function prevSlide(){
		    slides[index].classList.remove('active');
		    index = (index - 1 + slides.length) % slides.length;
		    slides[index].classList.add('active');
		}
	</script>
	<?php include 'components/alert.php'; ?>
</body>
</html>
