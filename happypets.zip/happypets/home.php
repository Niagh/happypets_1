<?php 
 include 'components/connection.php';
 session_start();
 if (isset($_SESSION['user_id'])) {
		$user_id = $_SESSION['user_id'];
	}else{
		$user_id = '';
	}

	if (isset($_POST['logout'])) {
		session_destroy();
		header("location: login.php");
	}
?>
<style type="text/css">
	<?php include 'style.css'; ?>
</style>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<title>Happy Pets - Accueil</title>
	<title>Redimensionnement des Images</title>
</head>
<body>
	<?php include 'components/header.php'; ?>
	<div class="main">
		
		<section class="home-section">
			<div class="slider">
				<div class="slider__slider slide1">
					<div class="overlay"></div>
					<div class="slide-detail">
						<h1>Bienvenue dans notre Animalerie !</h1>
						<p>Découvrez une gamme complète de produits pour vos compagnons à quatre pattes, spécialement sélectionnés pour leur bien-être.</p>
						<a href="view_products.php" class="btn">shop</a>
					</div>
					<div class="hero-dec-top"></div>
					<div class="hero-dec-bottom"></div>
				</div>
				<!-- slide end -->
				<div class="slider__slider slide2">
					<div class="overlay"></div>
					<div class="slide-detail">
						<h1>Confort Absolu pour Votre Chat</h1>
						<p>Offrez à votre félin des espaces de repos douillets et des accessoires ludiques pour un quotidien épanouissant.</p>
						<a href="view_products.php" class="btn">shop</a>
					</div>
					<div class="hero-dec-top"></div>
					<div class="hero-dec-bottom"></div>
				</div>
				<!-- slide end -->
				<div class="slider__slider slide3">
					<div class="overlay"></div>
					<div class="slide-detail">
						<h1>Jouets Interactifs pour Chiens</h1>
						<p>Stimulez l'esprit et les sens de votre chien avec notre sélection de jouets interactifs et résistants.</p>
						<a href="view_products.php" class="btn">shop</a>
					</div>
					<div class="hero-dec-top"></div>
					<div class="hero-dec-bottom"></div>
				</div>
				<!-- slide end -->
				<div class="slider__slider slide4">
					<div class="overlay"></div>
					<div class="slide-detail">
						<h1>Habitat Idéal pour Hamsters</h1>
						<p>Aménagez un environnement sûr et divertissant pour votre hamster avec nos accessoires et litières de qualité.</p>
						<a href="view_products.php" class="btn">shop</a>
					</div>
					<div class="hero-dec-top"></div>
					<div class="hero-dec-bottom"></div>
				</div>
				<!-- slide end -->
				<div class="slider__slider slide5">
					<div class="overlay"></div>
					<div class="slide-detail">
						<h1>Soins et Hygiène pour Tous Vos Animaux </h1>
						<p>Le meilleur choix pour vos amis les betes, plus de confort = plus de complicité</p>
						<a href="view_products.php" class="btn">shop</a>
					</div>
					<div class="hero-dec-top"></div>
					<div class="hero-dec-bottom"></div>
				</div>
				<!-- slide end -->
				<div class="left-arrow"><i class='bx bxs-left-arrow'></i></div>
                <div class="right-arrow"><i class='bx bxs-right-arrow'></i></div>
			</div>
		</section>
		<!-- home slider end -->
		<section class="thumb">
        <div class="box-container">
            <div class="box">
                <img src="img/M.jpg" class="icon" alt="Chien">
                <h3>Chien</h3>
                <i class="bx bx-chevron-right"></i>
            </div>
            <div class="box">
                <img src="img/tete-de-chat.png" class="icon" alt="Chat">
                <h3>Chat</h3>
                <i class="bx bx-chevron-right"></i>
            </div>
            <div class="box">
                <img src="img/hamster.png" class="icon" alt="Hamster">
                <h3>Hamster</h3>
                <i class="bx bx-chevron-right"></i>
            </div>
            <div class="box">
                <img src="img/des-os.png" class="icon" alt="Jouet">
                <h3>Jouet</h3>
                <i class="bx bx-chevron-right"></i>
            </div>
        </div>
    </section>
		<section class="container">
			<div class="box-container">
				<div class="box">
					<img src="img/about.jpg">
				</div>
				<div class="box">
					<img src="img/coucou.jpg">
					<span>Meilleurs offres</span>
					<h1>- 50%</h1>
				</div>
			</div>
		</section>
		<section class="shop">
			<div class="title">
				<img src="img/download.png">
				<h1>Tendance</h1>
			</div>
			<div class="row">
				<img src="img/about.jpg">
				<div class="row-detail">
					<img src="img/basil.jpg">
					<div class="top-footer">
						<h1>un petit plaisir pour votre chien ?</h1>
					</div>
				</div>
			</div>
			<div class="box-container">
				<div class="box">
					<img src="img/canin.webp">
					<a href="view_products.php" class="btn">shop</a>
				</div>
				<div class="box">
					<img src="img/chat.webp">
					<a href="view_products.php" class="btn">shop</a>
				</div>
				<div class="box">
					<img src="img/chat2.webp">
					<a href="view_products.php" class="btn">shop</a>
				</div>
				<div class="box">
					<img src="img/chat4.webp">
					<a href="view_products.php" class="btn">shop</a>
				</div>
				<div class="box">
					<img src="img/hamaison.webp">
					<a href="view_products.php" class="btn">shop</a>
				</div>
				<div class="box">
					<img src="img/ham10.webp">
					<a href="view_products.php" class="btn">shop</a>
				</div>
			</div>
		</section>
		
		<?php include 'components/footer.php'; ?>
	</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
	<script src="script.js"></script>
	<?php include 'components/alert.php'; ?>
</body>
</html>